import logo from './logo.svg';
import './App.css';
import MyComponents from './components/MyComponents'

function App() {
  return (
    <div className="App">
      <h1> Hello world</h1>
      고범종
      <MyComponents />
    </div>
  );
}

export default App;
