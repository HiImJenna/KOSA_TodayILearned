function Hello(){
    return(
        <div>
            <h1> hello component</h1>
            <p>리액트 재미있어요!!</p>
        </div>
    )
}

export default Hello;