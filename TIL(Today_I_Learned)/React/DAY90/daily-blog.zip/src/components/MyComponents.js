import {Component} from 'react';

class MyComponents extends Component{
    
    // constructor(){ this를 적음으로서 MyComponents 생성자에게 선언한다란 뜻이다
    //     this.state ={
    //         //상태변수(state variable)
    //         number: 0,
    //         age: 10,
    //         name: 'yuna'
    //     }
    // }


    // 상태변수 선언
    state = { //state를 적음으로서 그냥 일반 변수 선언이다
        number : 0,
        message : 'th1-703',
        validate : false,
        messages : ['AngularJS', 'React', 'Vue', 'Ember'] 
    }

    render(){

        const {message,number,validate,messages} = this.state;
        return(
            <>
                <h3>Hello {messages}</h3>
            </>
        )
    }

}

export default MyComponents;